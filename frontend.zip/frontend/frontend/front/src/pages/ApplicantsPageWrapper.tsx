import React from "react";
import ApplicantsPage from "./ApplicantsPage";

const ApplicantsPageWrapper: React.FC = () => {
  return <ApplicantsPage />; // просто рендерим компонент
};

export default ApplicantsPageWrapper;
